// ============================================
// GUARDIANES DE LA PAMPA - VERSIÓN MEJORADA
// Sistema de niveles, NPC Guardabosques, y mejoras
// ============================================

// ============================================
// CONSTANTES Y CONFIGURACIÓN DEL JUEGO
// ============================================

const GAME_CONFIG = {
  WORLD_WIDTH: 3000,
  WORLD_HEIGHT: 2000,
  TILE_SIZE: 50,

  PLAYER: {
    BASE_SPEED: 3,
    SIZE: 40,
    COLLECTION_RADIUS: 60,
    MAX_INVENTORY: 5,
  },

  WASTE: {
    SPAWN_INTERVAL: 3000,
    MAX_ON_MAP: 30, // Base, se aumenta con spawnBoost
    MAX_ON_MAP_BOOSTED: 50, // Con mejora
    SIZE: 30,
    TYPES: {
      plastic: {
        color: "#FFD700",
        icon: "🧴",
        name: "Plástico",
        info: "Tarda 500 años en degradarse",
      },
      glass: {
        color: "#228B22",
        icon: "🍾",
        name: "Vidrio",
        info: "Reciclable infinitas veces",
      },
      paper: {
        color: "#4169E1",
        icon: "📰",
        name: "Papel",
        info: "Salva árboles al reciclarse",
      },
      organic: {
        color: "#8B4513",
        icon: "🍎",
        name: "Orgánico",
        info: "Se convierte en compost",
      },
    },
  },

  CONTAINERS: {
    SIZE: 60,
    POSITIONS: [
      { x: 500, y: 500, type: "plastic" },
      { x: 700, y: 500, type: "glass" },
      { x: 900, y: 500, type: "paper" },
      { x: 1100, y: 500, type: "organic" },
    ],
  },

  RANGER: {
    X: 2000,
    Y: 1000,
    SIZE: 50,
    INTERACTION_RADIUS: 80,
  },

  HUNTER: {
    SIZE: 50,
    SPEED: 2,
    SPAWN_INTERVAL: 90000, // 90 segundos
    ESCAPE_TIME: 20000, // 20 segundos para atraparlo
    REWARD_POINTS: 300,
    PENALTY_POINTS_PERCENT: 10,
    PENALTY_WATER: 20,
    INTERACTION_RADIUS: 60,
  },

  POINTS: {
    CORRECT_SORT: 100,
    WRONG_SORT: -50,
    WATER_DECREASE_WRONG: 5,
    WATER_INCREASE_CORRECT: 2,
  },

  LEVELS: [
    {
      id: 1,
      name: "Pampa Verde",
      pointsGoal: 5000,
      background: {
        primary: "#A8D08D",
        secondary: "#7BA05B",
        tertiary: "#6B8E23",
      },
      terrain: "pampa",
    },
    {
      id: 2,
      name: "Oeste Pampeano",
      pointsGoal: 7000,
      background: {
        primary: "#D4A574",
        secondary: "#B8860B",
        tertiary: "#8B4513",
      },
      terrain: "desert",
    },
    {
      id: 3,
      name: "Sierras Pampeanas",
      pointsGoal: 9000,
      background: {
        primary: "#8B7355",
        secondary: "#696969",
        tertiary: "#556B2F",
      },
      terrain: "mountains",
    },
  ],

  UPGRADES: [
    {
      id: "speed1",
      name: "Botas Veloces I",
      description: "Aumenta tu velocidad de movimiento un 30%",
      icon: "👟",
      cost: 500,
      effect: { type: "speed", value: 1.3 },
      level: 1,
    },
    {
      id: "speed2",
      name: "Botas Veloces II",
      description: "Aumenta tu velocidad de movimiento un 60%",
      icon: "🥾",
      cost: 1200,
      effect: { type: "speed", value: 1.6 },
      level: 2,
      requires: "speed1",
    },
    {
      id: "inventory1",
      name: "Mochila Ampliada I",
      description: "Capacidad de inventario +3 (total: 8)",
      icon: "🎒",
      cost: 600,
      effect: { type: "inventory", value: 3 },
      level: 1,
    },
    {
      id: "inventory2",
      name: "Mochila Ampliada II",
      description: "Capacidad de inventario +5 (total: 13)",
      icon: "🎒",
      cost: 1500,
      effect: { type: "inventory", value: 5 },
      level: 2,
      requires: "inventory1",
    },
    {
      id: "radius1",
      name: "Detector Mejorado I",
      description: "Radio de recolección +30%",
      icon: "📡",
      cost: 700,
      effect: { type: "radius", value: 1.3 },
      level: 1,
    },
    {
      id: "radius2",
      name: "Detector Mejorado II",
      description: "Radio de recolección +60%",
      icon: "📡",
      cost: 1600,
      effect: { type: "radius", value: 1.6 },
      level: 2,
      requires: "radius1",
    },
    {
      id: "ecosystem",
      name: "Restaurador Ecológico",
      description: "Los animales aparecen más frecuentemente",
      icon: "🦙",
      cost: 2000,
      effect: { type: "ecosystem", value: true },
      level: 1,
    },
    {
      id: "autoCollect",
      name: "Recolección Automática",
      description: "Recoge residuos cercanos automáticamente",
      icon: "🤖",
      cost: 3000,
      effect: { type: "autoCollect", value: true },
      level: 1,
    },
  ],
};

// ============================================
// ESTADO DEL JUEGO
// ============================================

class GameState {
  constructor() {
    this.reset();
  }

  reset() {
    this.currentLevel = 1;
    this.points = 0;
    this.waterQuality = 100;
    this.collected = 0;
    this.correctSorts = 0;
    this.incorrectSorts = 0;
    this.startTime = Date.now();
    this.upgrades = new Set();

    // Misiones del guardabosques
    this.rangerQuest1Complete = false; // 13 botellas
    
    // Contadores de entregas parciales al guardabosques
    this.rangerDeliveredPlastic = 0;
    this.rangerDeliveredGlass = 0;
    this.rangerDeliveredPaper = 0;
    this.rangerDeliveredOrganic = 0;
    this.rangerQuest2Complete = false; // 30 de cada tipo
    this.hasWaterPurifier = false; // Mejora especial

    // Efectos acumulados de mejoras
    this.speedMultiplier = 1;
    this.inventoryBonus = 0;
    this.radiusMultiplier = 1;
    this.hasAutoCollect = false;
    this.ecosystemBoost = false;
    this.spawnBoost = false;

    // Estadísticas globales (acumuladas entre niveles)
    this.totalPointsAllLevels = 0;
    this.totalCollectedAllLevels = 0;
  }

  resetForNewLevel() {
    // Resetea para nuevo nivel, incluyendo puntos guardados y mejoras compradas
    this.points = 0;
    this.waterQuality = 100;
    this.collected = 0;
    this.correctSorts = 0;
    this.incorrectSorts = 0;
    this.rangerQuest1Complete = false;
    this.rangerQuest2Complete = false;
    
    // NUEVO: Reiniciar contadores de entregas
    this.rangerDeliveredPlastic = 0;
    this.rangerDeliveredGlass = 0;
    this.rangerDeliveredPaper = 0;
    this.rangerDeliveredOrganic = 0;
    
    // NUEVO: Resetear mejoras compradas (mantener hasWaterPurifier)
    const hadPurifier = this.hasWaterPurifier;
    this.upgrades.clear();
    this.hasWaterPurifier = hadPurifier;
    
    // Resetear efectos de mejoras
    this.speedMultiplier = 1;
    this.inventoryBonus = 0;
    this.radiusMultiplier = 1;
    this.hasAutoCollect = false;
    this.ecosystemBoost = false;
    this.spawnBoost = false;
  }

  addPoints(amount) {
    this.points += amount;
    this.totalPointsAllLevels += amount > 0 ? amount : 0;
    this.updateHUD();
    this.checkLevelCompletion();
  }

  changeWaterQuality(amount) {
    this.waterQuality = Math.max(0, Math.min(100, this.waterQuality + amount));
    this.updateHUD();
  }

  useWaterPurifier() {
    if (this.hasWaterPurifier && this.waterQuality < 100) {
      this.waterQuality = Math.min(100, this.waterQuality + 10);
      this.updateHUD();
      if (game) {
        game.notifications.show(
          "💧 Purificador Activado",
          "La calidad del agua ha mejorado +10%",
          "success",
          3000
        );
      }
      return true;
    }
    return false;
  }

  buyUpgrade(upgradeId) {
    const upgrade = GAME_CONFIG.UPGRADES.find((u) => u.id === upgradeId);
    if (!upgrade || this.points < upgrade.cost) return false;

    // Verificar requisitos
    if (upgrade.requires && !this.upgrades.has(upgrade.requires)) return false;

    this.points -= upgrade.cost;
    this.upgrades.add(upgradeId);

    // Aplicar efecto
    this.applyUpgradeEffect(upgrade.effect);

    this.updateHUD();
    this.checkLevelCompletion();
    return true;
  }

  applyUpgradeEffect(effect) {
    switch (effect.type) {
      case "speed":
        this.speedMultiplier = effect.value;
        break;
      case "inventory":
        this.inventoryBonus += effect.value;
        break;
      case "radius":
        this.radiusMultiplier = effect.value;
        break;
      case "autoCollect":
        this.hasAutoCollect = effect.value;
        break;
      case "ecosystem":
        this.ecosystemBoost = effect.value;
        break;
      case "spawnBoost":
        this.spawnBoost = effect.value;
        break;
    }
  }

  checkLevelCompletion() {
    const level = GAME_CONFIG.LEVELS[this.currentLevel - 1];
    const allUpgrades = this.upgrades.size >= 9;

    // Actualizar objetivos en HUD
    const objPoints = document.getElementById("obj-points");
    const objWater = document.getElementById("obj-water");
    const objUpgrades = document.getElementById("obj-upgrades");
    const objRanger = document.getElementById("obj-ranger");

    const pointsComplete = this.points >= level.pointsGoal;
    const waterComplete = this.waterQuality >= 100;
    const upgradesComplete = allUpgrades;
    const rangerComplete =
      this.rangerQuest1Complete && this.rangerQuest2Complete;

    if (objPoints) {
      objPoints.className =
        "objective-item" + (pointsComplete ? " completed" : "");
      document.getElementById(
        "objPointsText"
      ).textContent = `${this.points}/${level.pointsGoal} puntos`;
    }

    if (objWater) {
      objWater.className =
        "objective-item" + (waterComplete ? " completed" : "");
    }

    if (objUpgrades) {
      objUpgrades.className =
        "objective-item" + (upgradesComplete ? " completed" : "");
      document.getElementById(
        "objUpgradesText"
      ).textContent = `${this.upgrades.size}/9 mejoras`;
    }

    if (objRanger) {
      objRanger.className =
        "objective-item" + (rangerComplete ? " completed" : "");
      let rangerText = "Misiones del guardabosques";
      if (rangerComplete) rangerText = "✓ Misiones completadas";
      else if (this.rangerQuest1Complete) rangerText = "Misión 2 pendiente";
      document.getElementById("objRangerText").textContent = rangerText;
    }

    // Barra de progreso
    const progress = (this.points / level.pointsGoal) * 100;
    document.getElementById("levelProgressBar").style.width =
      Math.min(progress, 100) + "%";

    // Verificar si se completó el nivel
    if (pointsComplete && waterComplete && upgradesComplete && rangerComplete) {
      if (game && !game.paused) {
        setTimeout(() => {
          game.showVictoryScreen();
        }, 1000);
      }
    }
  }

  updateHUD() {
    document.getElementById("pointsDisplay").textContent = this.points;
    document.getElementById("waterQualityPercent").textContent = `${Math.round(
      this.waterQuality
    )}%`;

    const waterFill = document.getElementById("waterQualityFill");
    waterFill.style.width = `${this.waterQuality}%`;

    if (this.waterQuality < 30) {
      waterFill.className = "water-quality-fill low";
    } else if (this.waterQuality < 60) {
      waterFill.className = "water-quality-fill medium";
    } else {
      waterFill.className = "water-quality-fill";
    }

    // Actualizar indicador de nivel
    const level = GAME_CONFIG.LEVELS[this.currentLevel - 1];
    document.getElementById(
      "levelDisplay"
    ).textContent = `Nivel ${this.currentLevel}: ${level.name}`;
    document.getElementById("pointsGoal").textContent = level.pointsGoal;
  }

  save() {
    const saveData = {
      currentLevel: this.currentLevel,
      points: this.points,
      waterQuality: this.waterQuality,
      collected: this.collected,
      correctSorts: this.correctSorts,
      incorrectSorts: this.incorrectSorts,
      upgrades: Array.from(this.upgrades),
      rangerQuest1Complete: this.rangerQuest1Complete,
      rangerQuest2Complete: this.rangerQuest2Complete,
      hasWaterPurifier: this.hasWaterPurifier,
      speedMultiplier: this.speedMultiplier,
      inventoryBonus: this.inventoryBonus,
      radiusMultiplier: this.radiusMultiplier,
      hasAutoCollect: this.hasAutoCollect,
      ecosystemBoost: this.ecosystemBoost,
      spawnBoost: this.spawnBoost || false,
      rangerDeliveredPlastic: this.rangerDeliveredPlastic || 0,
      rangerDeliveredGlass: this.rangerDeliveredGlass || 0,
      rangerDeliveredPaper: this.rangerDeliveredPaper || 0,
      rangerDeliveredOrganic: this.rangerDeliveredOrganic || 0,
      totalPointsAllLevels: this.totalPointsAllLevels,
      totalCollectedAllLevels: this.totalCollectedAllLevels,
      timestamp: Date.now(),
    };
    localStorage.setItem("guardianesDelaPampa_save", JSON.stringify(saveData));
    return true;
  }

  load() {
    const saved = localStorage.getItem("guardianesDelaPampa_save");
    if (!saved) return false;

    try {
      const data = JSON.parse(saved);
      this.currentLevel = data.currentLevel || 1;
      this.points = data.points || 0;
      this.waterQuality = data.waterQuality || 100;
      this.collected = data.collected || 0;
      this.correctSorts = data.correctSorts || 0;
      this.incorrectSorts = data.incorrectSorts || 0;
      this.upgrades = new Set(data.upgrades || []);
      this.rangerQuest1Complete = data.rangerQuest1Complete || false;
      this.rangerQuest2Complete = data.rangerQuest2Complete || false;
      this.hasWaterPurifier = data.hasWaterPurifier || false;
      this.speedMultiplier = data.speedMultiplier || 1;
      this.inventoryBonus = data.inventoryBonus || 0;
      this.radiusMultiplier = data.radiusMultiplier || 1;
      this.hasAutoCollect = data.hasAutoCollect || false;
      this.ecosystemBoost = data.ecosystemBoost || false;
      this.spawnBoost = data.spawnBoost || false;
      this.rangerDeliveredPlastic = data.rangerDeliveredPlastic || 0;
      this.rangerDeliveredGlass = data.rangerDeliveredGlass || 0;
      this.rangerDeliveredPaper = data.rangerDeliveredPaper || 0;
      this.rangerDeliveredOrganic = data.rangerDeliveredOrganic || 0;
      this.totalPointsAllLevels = data.totalPointsAllLevels || 0;
      this.totalCollectedAllLevels = data.totalCollectedAllLevels || 0;

      this.updateHUD();
      return true;
    } catch (e) {
      console.error("Error loading save:", e);
      return false;
    }
  }
}

// Instancia global del estado del juego
const gameState = new GameState();

// ============================================
// ENTIDADES DEL JUEGO
// ============================================

class Player {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = GAME_CONFIG.PLAYER.SIZE;
    this.inventory = [];
    this.direction = "down";
    this.frame = 0;
    this.animationTimer = 0;
  }

  get maxInventory() {
    return GAME_CONFIG.PLAYER.MAX_INVENTORY + gameState.inventoryBonus;
  }

  get speed() {
    return GAME_CONFIG.PLAYER.BASE_SPEED * gameState.speedMultiplier;
  }

  get collectionRadius() {
    return GAME_CONFIG.PLAYER.COLLECTION_RADIUS * gameState.radiusMultiplier;
  }

  move(dx, dy, world) {
    const newX = this.x + dx * this.speed;
    const newY = this.y + dy * this.speed;

    // Límites del mundo
    if (newX >= 0 && newX <= GAME_CONFIG.WORLD_WIDTH - this.size) {
      this.x = newX;
    }
    if (newY >= 0 && newY <= GAME_CONFIG.WORLD_HEIGHT - this.size) {
      this.y = newY;
    }

    // Actualizar dirección
    if (Math.abs(dx) > Math.abs(dy)) {
      this.direction = dx > 0 ? "right" : "left";
    } else if (dy !== 0) {
      this.direction = dy > 0 ? "down" : "up";
    }

    // Animación
    this.animationTimer++;
    if (this.animationTimer > 10) {
      this.frame = (this.frame + 1) % 4;
      this.animationTimer = 0;
    }
  }

  addToInventory(waste) {
    if (this.inventory.length < this.maxInventory) {
      this.inventory.push(waste);
      this.updateInventoryUI();
      return true;
    }
    return false;
  }

  clearInventory() {
    this.inventory = [];
    this.updateInventoryUI();
  }

  updateInventoryUI() {
    document.getElementById(
      "inventoryDisplay"
    ).textContent = `${this.inventory.length}/${this.maxInventory}`;

    const inventoryList = document.getElementById("inventoryList");
    if (this.inventory.length === 0) {
      inventoryList.innerHTML =
        '<p style="color: #7F8C8D; text-align: center;">Vacío</p>';
    } else {
      // Agrupar por tipo
      const grouped = {};
      this.inventory.forEach((waste, index) => {
        if (!grouped[waste.type]) {
          grouped[waste.type] = { count: 0, indices: [] };
        }
        grouped[waste.type].count++;
        grouped[waste.type].indices.push(index);
      });

      inventoryList.innerHTML = Object.entries(grouped)
        .map(([type, data]) => {
          const config = GAME_CONFIG.WASTE.TYPES[type];
          return `
                    <div class="inventory-item ${type}">
                        <span class="inventory-item-icon">${config.icon}</span>
                        <div class="inventory-item-info">
                            <div class="inventory-item-name">${config.name} x${data.count}</div>
                            <div class="inventory-item-type">${config.info}</div>
                        </div>
                    </div>
                `;
        })
        .join("");
    }
  }

  draw(ctx, camera) {
    const screenX = this.x - camera.x;
    const screenY = this.y - camera.y;

    // Sombra
    ctx.fillStyle = "rgba(0, 0, 0, 0.3)";
    ctx.beginPath();
    ctx.ellipse(
      screenX + this.size / 2,
      screenY + this.size + 5,
      this.size / 2.5,
      this.size / 6,
      0,
      0,
      Math.PI * 2
    );
    ctx.fill();

    // Radio de recolección (visual)
    if (keys["e"] || gameState.hasAutoCollect) {
      ctx.strokeStyle = "rgba(123, 160, 91, 0.3)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(
        screenX + this.size / 2,
        screenY + this.size / 2,
        this.collectionRadius,
        0,
        Math.PI * 2
      );
      ctx.stroke();
    }

    // Dibujar personaje con emoji de vaquero 🤠
    ctx.save();
    ctx.font = `${this.size * 1.8}px Arial`; // Más grande para que se vea bien
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    // Personaje guardián con sombrero vaquero
    if (this.direction === "left") {
      ctx.scale(-1, 1);
      ctx.fillText("🧑‍🌾", -(screenX + this.size / 2), screenY + this.size / 2);
    } else {
      ctx.fillText("🧑‍🌾", screenX + this.size / 2, screenY + this.size / 2);
    }

    ctx.restore();

    // Indicador de inventario lleno
    if (this.inventory.length === this.maxInventory) {
      ctx.fillStyle = "#F39C12";
      ctx.font = "bold 14px Arial";
      ctx.textAlign = "center";
      ctx.fillText("¡Lleno!", screenX + this.size / 2, screenY - 15);
    }
  }
}

class Waste {
  constructor(x, y, type) {
    this.x = x;
    this.y = y;
    this.type = type;
    this.size = GAME_CONFIG.WASTE.SIZE;
    this.collected = false;
    this.bobOffset = Math.random() * Math.PI * 2;
  }

  update(time) {
    // Efecto de flotación
    this.floatY = Math.sin(time * 0.002 + this.bobOffset) * 3;
  }

  draw(ctx, camera) {
    if (this.collected) return;

    const screenX = this.x - camera.x;
    const screenY = this.y - camera.y + this.floatY;

    const config = GAME_CONFIG.WASTE.TYPES[this.type];

    // Sombra
    ctx.fillStyle = "rgba(0, 0, 0, 0.2)";
    ctx.beginPath();
    ctx.ellipse(
      screenX + this.size / 2,
      screenY + this.size,
      this.size / 3,
      this.size / 8,
      0,
      0,
      Math.PI * 2
    );
    ctx.fill();

    // Fondo del residuo
    ctx.fillStyle = config.color;
    ctx.beginPath();
    ctx.arc(
      screenX + this.size / 2,
      screenY + this.size / 2,
      this.size / 2,
      0,
      Math.PI * 2
    );
    ctx.fill();

    // Borde
    ctx.strokeStyle = "rgba(0, 0, 0, 0.2)";
    ctx.lineWidth = 2;
    ctx.stroke();

    // Icono
    ctx.font = `${this.size / 1.5}px Arial`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(config.icon, screenX + this.size / 2, screenY + this.size / 2);
  }
}

class Container {
  constructor(x, y, type) {
    this.x = x;
    this.y = y;
    this.type = type;
    this.size = GAME_CONFIG.CONTAINERS.SIZE;
    this.glowPhase = 0;
  }

  update(time) {
    this.glowPhase = time * 0.002;
  }

  checkCollision(player) {
    const dx = player.x + player.size / 2 - (this.x + this.size / 2);
    const dy = player.y + player.size / 2 - (this.y + this.size / 2);
    const distance = Math.sqrt(dx * dx + dy * dy);
    return distance < this.size / 2 + player.size / 2;
  }

  draw(ctx, camera) {
    const screenX = this.x - camera.x;
    const screenY = this.y - camera.y;

    const config = GAME_CONFIG.WASTE.TYPES[this.type];

    // Resplandor pulsante
    const glowIntensity = 0.5 + Math.sin(this.glowPhase) * 0.2;
    ctx.shadowColor = config.color;
    ctx.shadowBlur = 20 * glowIntensity;

    // Contenedor
    ctx.fillStyle = config.color;
    ctx.fillRect(screenX, screenY, this.size, this.size * 1.2);

    ctx.shadowBlur = 0;

    // Borde oscuro
    ctx.strokeStyle = "rgba(0, 0, 0, 0.3)";
    ctx.lineWidth = 3;
    ctx.strokeRect(screenX, screenY, this.size, this.size * 1.2);

    // Tapa
    ctx.fillStyle = "rgba(0, 0, 0, 0.2)";
    ctx.fillRect(screenX, screenY, this.size, this.size * 0.2);

    // Icono
    ctx.font = `${this.size / 2}px Arial`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillStyle = "white";
    ctx.strokeStyle = "rgba(0, 0, 0, 0.5)";
    ctx.lineWidth = 2;
    ctx.strokeText(
      config.icon,
      screenX + this.size / 2,
      screenY + this.size * 0.7
    );
    ctx.fillText(
      config.icon,
      screenX + this.size / 2,
      screenY + this.size * 0.7
    );

    // Etiqueta
    ctx.font = "bold 12px Arial";
    ctx.fillStyle = "white";
    ctx.strokeStyle = "rgba(0, 0, 0, 0.7)";
    ctx.lineWidth = 3;
    ctx.strokeText(
      config.name.toUpperCase(),
      screenX + this.size / 2,
      screenY + this.size * 1.35
    );
    ctx.fillText(
      config.name.toUpperCase(),
      screenX + this.size / 2,
      screenY + this.size * 1.35
    );
  }
}

class Ranger {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = GAME_CONFIG.RANGER.SIZE;
    this.interactionRadius = GAME_CONFIG.RANGER.INTERACTION_RADIUS;
    this.animationPhase = 0;
  }

  update(time) {
    this.animationPhase = time * 0.001;
  }

  checkInteraction(player) {
    const dx = player.x + player.size / 2 - (this.x + this.size / 2);
    const dy = player.y + player.size / 2 - (this.y + this.size / 2);
    const distance = Math.sqrt(dx * dx + dy * dy);
    return distance < this.interactionRadius;
  }

  draw(ctx, camera) {
    const screenX = this.x - camera.x;
    const screenY = this.y - camera.y;

    // Solo dibujar si está en pantalla
    if (
      screenX < -this.size ||
      screenX > camera.width + this.size ||
      screenY < -this.size ||
      screenY > camera.height + this.size
    ) {
      return;
    }

    // Sombra
    ctx.fillStyle = "rgba(0, 0, 0, 0.3)";
    ctx.beginPath();
    ctx.ellipse(
      screenX + this.size / 2,
      screenY + this.size + 5,
      this.size / 2.5,
      this.size / 6,
      0,
      0,
      Math.PI * 2
    );
    ctx.fill();

    // Indicador de misión disponible
    if (!gameState.rangerQuest1Complete || !gameState.rangerQuest2Complete) {
      const bounce = Math.sin(this.animationPhase * 3) * 5;
      ctx.font = "30px Arial";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("❗", screenX + this.size / 2, screenY - 30 + bounce);
    }

    // Dibujar guardabosques
    ctx.font = `${this.size * 1.5}px Arial`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("🧑‍🚒", screenX + this.size / 2, screenY + this.size / 2);

    // Etiqueta
    ctx.font = "bold 14px Arial";
    ctx.fillStyle = "white";
    ctx.strokeStyle = "rgba(0, 0, 0, 0.7)";
    ctx.lineWidth = 3;
    ctx.strokeText(
      "Guardabosques",
      screenX + this.size / 2,
      screenY + this.size + 25
    );
    ctx.fillText(
      "Guardabosques",
      screenX + this.size / 2,
      screenY + this.size + 25
    );
  }
}

class Hunter {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = GAME_CONFIG.HUNTER.SIZE;
    this.speed = GAME_CONFIG.HUNTER.SPEED;
    this.interactionRadius = GAME_CONFIG.HUNTER.INTERACTION_RADIUS;
    this.active = false;
    this.escapeTime = GAME_CONFIG.HUNTER.ESCAPE_TIME;
    this.spawnTime = 0;
    this.vx = (Math.random() - 0.5) * this.speed;
    this.vy = (Math.random() - 0.5) * this.speed;
    this.animationPhase = 0;
  }

  spawn() {
    // Posición aleatoria en el mapa
    this.x = Math.random() * (GAME_CONFIG.WORLD_WIDTH - 200) + 100;
    this.y = Math.random() * (GAME_CONFIG.WORLD_HEIGHT - 200) + 100;
    this.active = true;
    this.spawnTime = Date.now();
    this.vx = (Math.random() - 0.5) * this.speed * 2;
    this.vy = (Math.random() - 0.5) * this.speed * 2;
  }

  update(time) {
    if (!this.active) return;

    this.animationPhase = time * 0.003;

    // Movimiento errático del cazador
    this.x += this.vx;
    this.y += this.vy;

    // Rebotar en los bordes
    if (this.x < 50 || this.x > GAME_CONFIG.WORLD_WIDTH - 50) {
      this.vx *= -1;
    }
    if (this.y < 50 || this.y > GAME_CONFIG.WORLD_HEIGHT - 50) {
      this.vy *= -1;
    }

    // Cambiar dirección ocasionalmente
    if (Math.random() < 0.02) {
      this.vx = (Math.random() - 0.5) * this.speed * 2;
      this.vy = (Math.random() - 0.5) * this.speed * 2;
    }

    // Verificar si se escapó
    if (Date.now() - this.spawnTime > this.escapeTime) {
      return true; // Se escapó
    }

    return false;
  }

  checkCapture(player) {
    if (!this.active) return false;

    const dx = player.x + player.size / 2 - (this.x + this.size / 2);
    const dy = player.y + player.size / 2 - (this.y + this.size / 2);
    const distance = Math.sqrt(dx * dx + dy * dy);
    return distance < this.interactionRadius;
  }

  capture() {
    this.active = false;
  }

  escape() {
    this.active = false;
  }

  getRemainingTime() {
    return Math.max(0, this.escapeTime - (Date.now() - this.spawnTime));
  }

  draw(ctx, camera) {
    if (!this.active) return;

    const screenX = this.x - camera.x;
    const screenY = this.y - camera.y;

    // Solo dibujar si está en pantalla
    if (
      screenX < -this.size ||
      screenX > camera.width + this.size ||
      screenY < -this.size ||
      screenY > camera.height + this.size
    ) {
      return;
    }

    // Sombra
    ctx.fillStyle = "rgba(0, 0, 0, 0.3)";
    ctx.beginPath();
    ctx.ellipse(
      screenX + this.size / 2,
      screenY + this.size + 5,
      this.size / 2.5,
      this.size / 6,
      0,
      0,
      Math.PI * 2
    );
    ctx.fill();

    // Aura de peligro pulsante
    const pulseSize = this.size + Math.sin(this.animationPhase * 5) * 10;
    ctx.fillStyle = "rgba(231, 76, 60, 0.2)";
    ctx.beginPath();
    ctx.arc(
      screenX + this.size / 2,
      screenY + this.size / 2,
      pulseSize / 2,
      0,
      Math.PI * 2
    );
    ctx.fill();

    // Indicador de alerta encima
    const bounce = Math.sin(this.animationPhase * 5) * 8;
    ctx.font = "35px Arial";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("⚠️", screenX + this.size / 2, screenY - 35 + bounce);

    // Dibujar cazador (villano)
    ctx.font = `${this.size * 1.5}px Arial`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("🥷", screenX + this.size / 2, screenY + this.size / 2);

    // Etiqueta con fondo rojo
    ctx.fillStyle = "rgba(231, 76, 60, 0.9)";
    ctx.fillRect(screenX - 10, screenY + this.size + 15, this.size + 20, 25);

    ctx.font = "bold 14px Arial";
    ctx.fillStyle = "white";
    ctx.strokeStyle = "rgba(0, 0, 0, 0.7)";
    ctx.lineWidth = 3;
    ctx.strokeText(
      "CAZADOR",
      screenX + this.size / 2,
      screenY + this.size + 27
    );
    ctx.fillText("CAZADOR", screenX + this.size / 2, screenY + this.size + 27);
  }
}

class Animal {
  constructor(x, y, type) {
    this.x = x;
    this.y = y;
    this.type = type; // 'nandu' o 'vizcacha'
    this.size = type === "nandu" ? 50 : 30;
    this.vx = (Math.random() - 0.5) * 2;
    this.vy = (Math.random() - 0.5) * 2;
    this.frame = 0;
    this.animTimer = 0;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;

    // Rebotar en los bordes
    if (this.x < 0 || this.x > GAME_CONFIG.WORLD_WIDTH) this.vx *= -1;
    if (this.y < 0 || this.y > GAME_CONFIG.WORLD_HEIGHT) this.vy *= -1;

    this.animTimer++;
    if (this.animTimer > 15) {
      this.frame = (this.frame + 1) % 2;
      this.animTimer = 0;
    }
  }

  draw(ctx, camera) {
    const screenX = this.x - camera.x;
    const screenY = this.y - camera.y;

    // Solo dibujar si está en pantalla
    if (
      screenX < -this.size ||
      screenX > camera.width + this.size ||
      screenY < -this.size ||
      screenY > camera.height + this.size
    ) {
      return;
    }

    ctx.save();
    ctx.font = `${this.size}px Arial`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    if (this.type === "nandu") {
      ctx.fillText("🦙", screenX, screenY);
    } else if (this.type === "vizcacha") {
      ctx.fillText("🐁", screenX, screenY);
    } else if (this.type === "jabalí") {
      ctx.fillText("🐗", screenX, screenY);
    } else if (this.type === "buho") {
      ctx.fillText("🦉", screenX, screenY);
    } else if (this.type === "ciervo") {
      ctx.fillText("🦌", screenX, screenY);
    }
    ctx.restore();
  }
}

// ============================================
// MUNDO Y CÁMARA
// ============================================

class World {
  constructor() {
    this.width = GAME_CONFIG.WORLD_WIDTH;
    this.height = GAME_CONFIG.WORLD_HEIGHT;
    this.currentTerrain = "pampa";
    this.generateTerrain();
  }

  setTerrain(terrainType) {
    this.currentTerrain = terrainType;
    this.generateTerrain();
  }

  generateTerrain() {
    // Generar elementos decorativos del mundo
    this.grass = [];
    this.trees = [];
    this.waterBodies = [];
    this.rocks = [];
    this.cacti = [];

    // Pasto decorativo (solo en pampa y sierras)
    if (
      this.currentTerrain === "pampa" ||
      this.currentTerrain === "mountains"
    ) {
      for (let i = 0; i < 200; i++) {
        this.grass.push({
          x: Math.random() * this.width,
          y: Math.random() * this.height,
          type: Math.floor(Math.random() * 3),
        });
      }
    }

    // Árboles (varía según terreno)
    const treeCount = this.currentTerrain === "desert" ? 10 : 50;
    for (let i = 0; i < treeCount; i++) {
      this.trees.push({
        x: Math.random() * this.width,
        y: Math.random() * this.height,
        size: 40 + Math.random() * 40,
      });
    }

    // Cuerpos de agua (menos en desierto)
    const waterCount = this.currentTerrain === "desert" ? 1 : 3;
    if (waterCount > 0) {
      this.waterBodies = [
        { x: 1500, y: 1000, width: 400, height: 300, type: "lagoon" },
      ];
      if (waterCount > 1) {
        this.waterBodies.push(
          { x: 300, y: 1400, width: 600, height: 150, type: "stream" },
          { x: 2200, y: 600, width: 500, height: 200, type: "lagoon" }
        );
      }
    }

    // Rocas (más en sierras y desierto)
    if (
      this.currentTerrain === "mountains" ||
      this.currentTerrain === "desert"
    ) {
      const rockCount = this.currentTerrain === "mountains" ? 100 : 50;
      for (let i = 0; i < rockCount; i++) {
        this.rocks.push({
          x: Math.random() * this.width,
          y: Math.random() * this.height,
          size: 20 + Math.random() * 40,
        });
      }
    }

    // Cactus (solo en desierto)
    if (this.currentTerrain === "desert") {
      for (let i = 0; i < 30; i++) {
        this.cacti.push({
          x: Math.random() * this.width,
          y: Math.random() * this.height,
          size: 30 + Math.random() * 30,
        });
      }
    }
  }

  draw(ctx, camera) {
    // Obtener colores del nivel actual
    const level = GAME_CONFIG.LEVELS[gameState.currentLevel - 1];
    const colors = level.background;

    // Fondo base
    const gradient = ctx.createLinearGradient(0, 0, 0, ctx.canvas.height);
    gradient.addColorStop(0, colors.primary);
    gradient.addColorStop(0.5, colors.secondary);
    gradient.addColorStop(1, colors.tertiary);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);

    // Dibujar cuerpos de agua
    this.waterBodies.forEach((water) => {
      const screenX = water.x - camera.x;
      const screenY = water.y - camera.y;

      // Solo dibujar si está en pantalla
      if (
        screenX + water.width > 0 &&
        screenX < ctx.canvas.width &&
        screenY + water.height > 0 &&
        screenY < ctx.canvas.height
      ) {
        // Calidad del agua afecta el color
        const waterQuality = gameState.waterQuality / 100;
        const r = Math.floor(74 + (200 - 74) * (1 - waterQuality));
        const g = Math.floor(144 + (100 - 144) * (1 - waterQuality));
        const b = Math.floor(226 + (50 - 226) * (1 - waterQuality));

        ctx.fillStyle = `rgb(${r}, ${g}, ${b})`;
        ctx.beginPath();
        ctx.ellipse(
          screenX + water.width / 2,
          screenY + water.height / 2,
          water.width / 2,
          water.height / 2,
          0,
          0,
          Math.PI * 2
        );
        ctx.fill();

        // Borde
        ctx.strokeStyle = "rgba(0, 0, 0, 0.2)";
        ctx.lineWidth = 3;
        ctx.stroke();

        // Reflejos
        ctx.fillStyle = "rgba(255, 255, 255, 0.2)";
        ctx.beginPath();
        ctx.ellipse(
          screenX + water.width / 2 - 20,
          screenY + water.height / 2 - 10,
          water.width / 4,
          water.height / 6,
          0,
          0,
          Math.PI * 2
        );
        ctx.fill();
      }
    });

    // Dibujar pasto decorativo
    this.grass.forEach((g) => {
      const screenX = g.x - camera.x;
      const screenY = g.y - camera.y;

      if (
        screenX > -20 &&
        screenX < ctx.canvas.width + 20 &&
        screenY > -20 &&
        screenY < ctx.canvas.height + 20
      ) {
        ctx.fillStyle =
          g.type === 0 ? "#8FBC8F" : g.type === 1 ? "#9ACD32" : "#6B8E23";
        ctx.font = "20px Arial";
        ctx.fillText("🌿", screenX, screenY);
      }
    });

    // Dibujar rocas
    this.rocks.forEach((rock) => {
      const screenX = rock.x - camera.x;
      const screenY = rock.y - camera.y;

      if (
        screenX > -rock.size &&
        screenX < ctx.canvas.width + rock.size &&
        screenY > -rock.size &&
        screenY < ctx.canvas.height + rock.size
      ) {
        ctx.fillStyle = "#696969";
        ctx.beginPath();
        ctx.ellipse(
          screenX,
          screenY,
          rock.size / 2,
          rock.size / 3,
          0,
          0,
          Math.PI * 2
        );
        ctx.fill();
        ctx.strokeStyle = "#555555";
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    });

    // Dibujar cactus
    this.cacti.forEach((cactus) => {
      const screenX = cactus.x - camera.x;
      const screenY = cactus.y - camera.y;

      if (
        screenX > -cactus.size &&
        screenX < ctx.canvas.width + cactus.size &&
        screenY > -cactus.size &&
        screenY < ctx.canvas.height + cactus.size
      ) {
        ctx.font = `${cactus.size}px Arial`;
        ctx.textAlign = "center";
        ctx.fillText("🌵", screenX, screenY);
      }
    });

    // Dibujar árboles
    this.trees.forEach((tree) => {
      const screenX = tree.x - camera.x;
      const screenY = tree.y - camera.y;

      if (
        screenX > -tree.size &&
        screenX < ctx.canvas.width + tree.size &&
        screenY > -tree.size &&
        screenY < ctx.canvas.height + tree.size
      ) {
        // Tronco
        ctx.fillStyle = "#8B4513";
        ctx.fillRect(
          screenX - tree.size / 8,
          screenY,
          tree.size / 4,
          tree.size / 2
        );

        // Copa
        ctx.fillStyle = "#2D5016";
        ctx.beginPath();
        ctx.arc(screenX, screenY, tree.size / 2, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#3A6B23";
        ctx.beginPath();
        ctx.arc(
          screenX - tree.size / 6,
          screenY - tree.size / 6,
          tree.size / 3,
          0,
          Math.PI * 2
        );
        ctx.fill();
      }
    });
  }
}

class Camera {
  constructor(canvasWidth, canvasHeight) {
    this.x = 0;
    this.y = 0;
    this.width = canvasWidth;
    this.height = canvasHeight;
  }

  follow(player) {
    // Centrar la cámara en el jugador
    this.x = player.x + player.size / 2 - this.width / 2;
    this.y = player.y + player.size / 2 - this.height / 2;

    // Límites del mundo
    this.x = Math.max(
      0,
      Math.min(this.x, GAME_CONFIG.WORLD_WIDTH - this.width)
    );
    this.y = Math.max(
      0,
      Math.min(this.y, GAME_CONFIG.WORLD_HEIGHT - this.height)
    );
  }

  resize(width, height) {
    this.width = width;
    this.height = height;
  }
}

// ============================================
// SISTEMA DE NOTIFICACIONES
// ============================================

class NotificationSystem {
  constructor() {
    this.container = document.getElementById("notificationContainer");
    this.notifications = [];
  }

  show(title, message, type = "info", duration = 3000) {
    const id = Date.now() + Math.random();

    const icons = {
      success: "✅",
      error: "❌",
      info: "ℹ️",
      warning: "⚠️",
    };

    const notif = document.createElement("div");
    notif.className = `notification ${type}`;
    notif.innerHTML = `
            <span class="notification-icon">${icons[type]}</span>
            <div class="notification-text">
                <div class="notification-title">${title}</div>
                <div class="notification-message">${message}</div>
            </div>
        `;

    this.container.appendChild(notif);
    this.notifications.push({ id, element: notif });

    setTimeout(() => {
      notif.style.animation = "slideInRight 0.5s ease-out reverse";
      setTimeout(() => {
        if (this.container.contains(notif)) {
          this.container.removeChild(notif);
        }
        this.notifications = this.notifications.filter((n) => n.id !== id);
      }, 500);
    }, duration);
  }
}

// ============================================
// GESTOR DEL JUEGO
// ============================================

class Game {
  constructor() {
    this.canvas = document.getElementById("gameCanvas");
    this.ctx = this.canvas.getContext("2d");
    this.resizeCanvas();

    this.world = new World();
    this.camera = new Camera(this.canvas.width, this.canvas.height);
    this.player = new Player(
      GAME_CONFIG.WORLD_WIDTH / 2,
      GAME_CONFIG.WORLD_HEIGHT / 2
    );
    this.wastes = [];
    this.containers = [];
    this.animals = [];
    this.ranger = new Ranger(GAME_CONFIG.RANGER.X, GAME_CONFIG.RANGER.Y);

    this.notifications = new NotificationSystem();

    this.lastWasteSpawn = 0;
    this.running = false;
    this.paused = false;

    // Sistema de depósito - ahora requiere tecla E
    this.nearContainer = null;
    this.canOpenDeposit = true;

    // Sistema de villano cazador
    this.hunter = new Hunter(0, 0);
    this.lastHunterSpawn = 0;
    this.hunterTimerElement = null;

    this.initContainers();
    this.initAnimals();

    window.addEventListener("resize", () => this.resizeCanvas());
  }

  resizeCanvas() {
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
    if (this.camera) {
      this.camera.resize(this.canvas.width, this.canvas.height);
    }
  }

  initContainers() {
    this.containers = [];
    GAME_CONFIG.CONTAINERS.POSITIONS.forEach((pos) => {
      this.containers.push(new Container(pos.x, pos.y, pos.type));
    });
  }

  // NUEVO: Inicialización de animales que depende de la calidad del agua
  initAnimals() {
    this.animals = [];

    // La cantidad de animales depende de la calidad del agua
    const waterQualityFactor = gameState.waterQuality / 100;
    
    // Si no hay agua (0%), no hay animales
    if (waterQualityFactor <= 0) return;

    // más variedad de fauna pampeana
    const animalTypes = ["nandu", "vizcacha", "jabalí", "buho", "ciervo"];
    const baseCount = gameState.ecosystemBoost ? 20 : 10;
    
    // Ajustar cantidad según calidad del agua
    const count = Math.floor(baseCount * waterQualityFactor);

    for (let i = 0; i < count; i++) {
      const type = animalTypes[Math.floor(Math.random() * animalTypes.length)];
      const x = Math.random() * GAME_CONFIG.WORLD_WIDTH;
      const y = Math.random() * GAME_CONFIG.WORLD_HEIGHT;
      this.animals.push(new Animal(x, y, type));
    }
  }



  changeLevel(newLevel) {
    if (newLevel > 3) return;

    gameState.currentLevel = newLevel;
    gameState.resetForNewLevel();

    // Cambiar terreno del mundo
    const level = GAME_CONFIG.LEVELS[newLevel - 1];
    this.world.setTerrain(level.terrain);

    // Limpiar entidades
    this.wastes = [];
    this.player.clearInventory();

    // Reiniciar posición del jugador
    this.player.x = GAME_CONFIG.WORLD_WIDTH / 2;
    this.player.y = GAME_CONFIG.WORLD_HEIGHT / 2;

    // Actualizar HUD
    gameState.updateHUD();
    gameState.checkLevelCompletion();

    this.notifications.show(
      "Nuevo Nivel",
      `Bienvenido a ${level.name}`,
      "success",
      4000
    );
  }

  start() {
    this.running = true;
    this.paused = false;
    this.gameLoop();
    gameState.updateHUD();
    gameState.checkLevelCompletion();
    this.notifications.show(
      "¡Juego Iniciado!",
      "Recoge residuos y protege el agua",
      "success"
    );
  }

  pause() {
    this.paused = true;
    showScreen("pauseScreen");
    this.updatePauseStats();
  }

  resume() {
    this.paused = false;
    showScreen("gameScreen");
  }

  updatePauseStats() {
    document.getElementById("pauseCollected").textContent = gameState.collected;
    document.getElementById("pauseCorrect").textContent =
      gameState.correctSorts;
    document.getElementById("pauseIncorrect").textContent =
      gameState.incorrectSorts;
    document.getElementById("pausePoints").textContent = gameState.points;
  }

  spawnWaste() {
    if (
      this.wastes.filter((w) => !w.collected).length >=
      this.getMaxWastes()
    )
      return;

    const types = Object.keys(GAME_CONFIG.WASTE.TYPES);
    const type = types[Math.floor(Math.random() * types.length)];

    const x = Math.random() * (GAME_CONFIG.WORLD_WIDTH - 100) + 50;
    const y = Math.random() * (GAME_CONFIG.WORLD_HEIGHT - 100) + 50;

    this.wastes.push(new Waste(x, y, type));
  }

  getMaxWastes() {
    // NUEVO: Máximo de residuos depende de la mejora spawnBoost
    const baseMax = GAME_CONFIG.WASTE.MAX_ON_MAP;
    const boostedMax = GAME_CONFIG.WASTE.MAX_ON_MAP_BOOSTED;
    return gameState.spawnBoost ? boostedMax : baseMax;
  }

  collectWaste() {
    if (this.player.inventory.length >= this.player.maxInventory) {
      this.notifications.show(
        "Inventario Lleno",
        "Lleva los residuos a los contenedores",
        "warning",
        2000
      );
      return;
    }

    const radius = this.player.collectionRadius;

    this.wastes.forEach((waste) => {
      if (waste.collected) return;

      const dx =
        this.player.x + this.player.size / 2 - (waste.x + waste.size / 2);
      const dy =
        this.player.y + this.player.size / 2 - (waste.y + waste.size / 2);
      const distance = Math.sqrt(dx * dx + dy * dy);

      if (distance < radius) {
        if (this.player.addToInventory(waste)) {
          waste.collected = true;
          gameState.collected++;
          gameState.totalCollectedAllLevels++;

          const wasteInfo = GAME_CONFIG.WASTE.TYPES[waste.type];
          this.notifications.show(
            `${wasteInfo.icon} ${wasteInfo.name} Recolectado`,
            wasteInfo.info,
            "info",
            2000
          );
        }
      }
    });
  }

  checkContainerCollisions() {
    // Nuevo sistema: detectar si estamos cerca de un contenedor
    this.nearContainer = null;

    if (this.player.inventory.length === 0) return;

    this.containers.forEach((container) => {
      if (container.checkCollision(this.player)) {
        this.nearContainer = container;
      }
    });
  }

  tryOpenDeposit() {
    // Solo se abre con la tecla E
    if (this.nearContainer && this.canOpenDeposit && keys["e"]) {
      this.openDepositModal(this.nearContainer);
      this.canOpenDeposit = false; // Evitar múltiples aperturas
    }
  }

  openDepositModal(container) {
    // Pausar el juego
    this.paused = true;

    // Mostrar la pantalla de depósito
    const containerConfig = GAME_CONFIG.WASTE.TYPES[container.type];
    document.getElementById("depositContainerType").textContent =
      containerConfig.name;
    document.getElementById("depositContainerType").style.backgroundColor =
      containerConfig.color;
    document.getElementById("depositContainerType").style.color = "white";
    document.getElementById("depositContainerType").style.padding = "5px 15px";
    document.getElementById("depositContainerType").style.borderRadius = "8px";

    // Agrupar inventario por tipo
    const grouped = {};
    this.player.inventory.forEach((waste, index) => {
      if (!grouped[waste.type]) {
        grouped[waste.type] = { count: 0, indices: [] };
      }
      grouped[waste.type].count++;
      grouped[waste.type].indices.push(index);
    });

    const depositList = document.getElementById("depositList");
    depositList.innerHTML = Object.entries(grouped)
      .map(([type, data]) => {
        const config = GAME_CONFIG.WASTE.TYPES[type];
        const isCorrect = type === container.type;

        return `
                <div class="deposit-item ${
                  isCorrect ? "correct" : "incorrect"
                }">
                    <span class="deposit-item-icon">${config.icon}</span>
                    <div class="deposit-item-info">
                        <div class="deposit-item-name">${config.name}</div>
                        <div class="deposit-item-type">${config.info}</div>
                        <div class="deposit-item-result ${
                          isCorrect ? "correct" : "incorrect"
                        }">
                            ${
                              isCorrect
                                ? "✅ Correcto: +" +
                                  GAME_CONFIG.POINTS.CORRECT_SORT * data.count +
                                  " puntos"
                                : "❌ Incorrecto: " +
                                  GAME_CONFIG.POINTS.WRONG_SORT * data.count +
                                  " puntos"
                            }
                        </div>
                    </div>
                    <span class="deposit-item-count">x${data.count}</span>
                    <button class="deposit-item-btn ${
                      isCorrect ? "deposit-correct" : "deposit-incorrect"
                    }" 
                            onclick="game.depositWasteType('${type}', '${
          container.type
        }')">
                        Depositar
                    </button>
                </div>
            `;
      })
      .join("");

    // Añadir botón de depositar todos
    depositList.innerHTML += `
            <div style="margin-top: 20px; text-align: center;">
                <button class="deposit-item-btn deposit-all" onclick="game.depositAllWaste('${container.type}')">
                    ♻️ Depositar Todo
                </button>
            </div>
        `;

    showScreen("depositScreen");
  }

  depositWasteType(wasteType, containerType) {
    // Remover todos los residuos de ese tipo
    const itemsToRemove = this.player.inventory.filter(
      (w) => w.type === wasteType
    );
    const isCorrect = wasteType === containerType;

    itemsToRemove.forEach((waste) => {
      const index = this.player.inventory.indexOf(waste);
      if (index !== -1) {
        this.player.inventory.splice(index, 1);

        if (isCorrect) {
          gameState.addPoints(GAME_CONFIG.POINTS.CORRECT_SORT);
          gameState.changeWaterQuality(
            GAME_CONFIG.POINTS.WATER_INCREASE_CORRECT
          );
          gameState.correctSorts++;
        } else {
          gameState.addPoints(GAME_CONFIG.POINTS.WRONG_SORT);
          gameState.changeWaterQuality(
            -GAME_CONFIG.POINTS.WATER_DECREASE_WRONG
          );
          gameState.incorrectSorts++;
        }
      }
    });

    this.player.updateInventoryUI();

    // Mostrar notificación
    if (isCorrect) {
      this.notifications.show(
        "¡Excelente! ✅",
        `${itemsToRemove.length} ${GAME_CONFIG.WASTE.TYPES[wasteType].name}(s) clasificado(s) correctamente`,
        "success"
      );
    } else {
      this.notifications.show(
        "¡Cuidado! ⚠️",
        `${itemsToRemove.length} ${GAME_CONFIG.WASTE.TYPES[wasteType].name}(s) mal clasificado(s). ¡El agua se contamina!`,
        "error"
      );
    }

    // Si el inventario está vacío, cerrar modal
    if (this.player.inventory.length === 0) {
      this.closeDepositModal();
    } else {
      // Actualizar la ventana
      const container = this.containers.find((c) => c.type === containerType);
      if (container) {
        this.openDepositModal(container);
      }
    }
  }

  depositAllWaste(containerType) {
    const itemsToSort = [...this.player.inventory];
    let correctCount = 0;
    let incorrectCount = 0;

    itemsToSort.forEach((waste) => {
      if (waste.type === containerType) {
        correctCount++;
        gameState.addPoints(GAME_CONFIG.POINTS.CORRECT_SORT);
        gameState.changeWaterQuality(GAME_CONFIG.POINTS.WATER_INCREASE_CORRECT);
        gameState.correctSorts++;
      } else {
        incorrectCount++;
        gameState.addPoints(GAME_CONFIG.POINTS.WRONG_SORT);
        gameState.changeWaterQuality(-GAME_CONFIG.POINTS.WATER_DECREASE_WRONG);
        gameState.incorrectSorts++;
      }
    });

    this.player.clearInventory();

    if (correctCount > 0 && incorrectCount === 0) {
      this.notifications.show(
        "¡Excelente! ✅",
        `${correctCount} residuo(s) clasificado(s) correctamente`,
        "success"
      );
    } else if (incorrectCount > 0) {
      this.notifications.show(
        "¡Atención!",
        `Correcto: ${correctCount} | Incorrecto: ${incorrectCount}`,
        incorrectCount > correctCount ? "error" : "warning"
      );
    }

    this.closeDepositModal();
  }

  closeDepositModal() {
    showScreen("gameScreen");
    this.paused = false;

    // Resetear tecla E para evitar reabrir inmediatamente
    keys["e"] = false;

    // Permitir abrir de nuevo después de un breve momento
    setTimeout(() => {
      this.canOpenDeposit = true;
    }, 500);
  }

  checkRangerInteraction() {
    if (keys["e"] && this.ranger.checkInteraction(this.player)) {
      this.showRangerDialog();
    }
  }


  // NUEVO: Función para entregar objetos al guardabosques
  deliverToRanger() {
    if (!this.player || !this.player.inventory || this.player.inventory.length === 0) {
      this.notifications.show(
        "📦 Inventario Vacío",
        "No tienes objetos para entregar al guardabosques",
        "warning",
        3000
      );
      return;
    }

    // Contar objetos por tipo en el inventario
    const inventoryCount = {
      plastic: 0,
      glass: 0,
      paper: 0,
      organic: 0
    };

    this.player.inventory.forEach(waste => {
      if (inventoryCount.hasOwnProperty(waste.type)) {
        inventoryCount[waste.type]++;
      }
    });

    // Calcular cuántos objetos se pueden entregar (máximo 30 de cada tipo)
    const delivered = {
      plastic: Math.min(inventoryCount.plastic, 30 - gameState.rangerDeliveredPlastic),
      glass: Math.min(inventoryCount.glass, 30 - gameState.rangerDeliveredGlass),
      paper: Math.min(inventoryCount.paper, 30 - gameState.rangerDeliveredPaper),
      organic: Math.min(inventoryCount.organic, 30 - gameState.rangerDeliveredOrganic)
    };

    // Verificar si se puede entregar algo
    const totalToDeliver = delivered.plastic + delivered.glass + delivered.paper + delivered.organic;

    if (totalToDeliver === 0) {
      this.notifications.show(
        "✅ Misión Completa",
        "Ya has entregado 30 de cada tipo al guardabosques",
        "success",
        3000
      );
      return;
    }

    // Entregar los objetos
    gameState.rangerDeliveredPlastic += delivered.plastic;
    gameState.rangerDeliveredGlass += delivered.glass;
    gameState.rangerDeliveredPaper += delivered.paper;
    gameState.rangerDeliveredOrganic += delivered.organic;

    // Remover objetos del inventario
    let toRemove = { ...delivered };
    this.player.inventory = this.player.inventory.filter(waste => {
      if (toRemove[waste.type] > 0) {
        toRemove[waste.type]--;
        return false; // Remover este objeto
      }
      return true; // Mantener este objeto
    });

    this.player.updateInventoryUI();

    // Verificar si completó la misión 1 (13 objetos en total)
    const totalDelivered = gameState.rangerDeliveredPlastic + gameState.rangerDeliveredGlass + 
                           gameState.rangerDeliveredPaper + gameState.rangerDeliveredOrganic;
    
    if (!gameState.rangerQuest1Complete && totalDelivered >= 13) {
      gameState.rangerQuest1Complete = true;
      this.notifications.show(
        "🎉 ¡Misión 1 Completada!",
        "Has entregado 13 objetos al guardabosques",
        "success",
        4000
      );
    }

    // Verificar si completó la misión 2 (30 de cada tipo)
    if (!gameState.rangerQuest2Complete &&
        gameState.rangerDeliveredPlastic >= 30 &&
        gameState.rangerDeliveredGlass >= 30 &&
        gameState.rangerDeliveredPaper >= 30 &&
        gameState.rangerDeliveredOrganic >= 30) {
      gameState.rangerQuest2Complete = true;
      gameState.hasWaterPurifier = true;
      this.notifications.show(
        "🏆 ¡Misión 2 Completada!",
        "¡Has conseguido el Purificador de Agua! (Presiona P para usarlo)",
        "success",
        5000
      );
    }

    gameState.checkLevelCompletion();

    // Mostrar mensaje con progreso
    let message = `Entregado: `;
    if (delivered.plastic > 0) message += `🟨${delivered.plastic} `;
    if (delivered.glass > 0) message += `🟩${delivered.glass} `;
    if (delivered.paper > 0) message += `🟦${delivered.paper} `;
    if (delivered.organic > 0) message += `🟫${delivered.organic}`;
    
    message += `\n\nProgreso: ${gameState.rangerDeliveredPlastic}/30🟨 ${gameState.rangerDeliveredGlass}/30🟩 ${gameState.rangerDeliveredPaper}/30🟦 ${gameState.rangerDeliveredOrganic}/30🟫`;

    this.notifications.show(
      "🎁 Entrega Realizada",
      message,
      "success",
      4000
    );
  }

  showRangerDialog() {
    const dialog = document.getElementById("npcDialog");
    const playerScreenX = this.player.x - this.camera.x;
    const playerScreenY = this.player.y - this.camera.y;

    // Posicionar diálogo cerca del jugador
    dialog.style.left = playerScreenX + 60 + "px";
    dialog.style.top = playerScreenY - 100 + "px";
    dialog.style.display = "block";

    // Determinar qué misión mostrar
    if (!gameState.rangerQuest1Complete) {
      this.showQuest1Dialog(dialog);
    } else if (!gameState.rangerQuest2Complete) {
      this.showQuest2Dialog(dialog);
    } else {
      this.showQuestCompleteDialog(dialog);
    }

    this.paused = true;
  }

  showQuest1Dialog(dialog) {
    // Contar botellas de plástico en inventario
    const plasticCount = this.player.inventory.filter(
      (w) => w.type === "plastic"
    ).length;

    dialog.innerHTML = `
            <div class="npc-dialog-title">🧑‍🌾 Guardabosques</div>
            <div class="npc-dialog-text">
                ¡Hola, guardián! Necesito tu ayuda. He visto muchas <strong>botellas de plástico</strong> 
                contaminando nuestros arroyos. Si me traes <strong>13 botellas</strong>, 
                te daré mi <strong>Purificador de Agua Avanzado</strong> 🌊, 
                una herramienta única que restaura la calidad del agua instantáneamente.
                <br><br>
                Llevas: <strong>${plasticCount}/13 botellas</strong>
            </div>
            <div class="npc-dialog-buttons">
                ${
                  plasticCount >= 13
                    ? '<button class="npc-dialog-btn accept" onclick="game.completeQuest1()">Entregar botellas</button>'
                    : '<button class="npc-dialog-btn decline" onclick="game.closeRangerDialog()">Volver luego</button>'
                }
                <button class="npc-dialog-btn decline" onclick="game.closeRangerDialog()">Cerrar</button>
            </div>
        `;
  }

  showQuest2Dialog(dialog) {
    // Contar todos los tipos de residuos
    const counts = {
      plastic: this.player.inventory.filter((w) => w.type === "plastic").length,
      glass: this.player.inventory.filter((w) => w.type === "glass").length,
      paper: this.player.inventory.filter((w) => w.type === "paper").length,
      organic: this.player.inventory.filter((w) => w.type === "organic").length,
    };

    const hasAll =
      counts.plastic >= 30 &&
      counts.glass >= 30 &&
      counts.paper >= 30 &&
      counts.organic >= 30;

    dialog.innerHTML = `
            <div class="npc-dialog-title">🧑‍🌾 Guardabosques</div>
            <div class="npc-dialog-text">
                ¡Gracias por el purificador! Ahora tengo otra misión urgente. 
                Los <strong>cazadores furtivos</strong> están poniendo en peligro nuestra fauna. 
                Necesito <strong>30 de cada tipo de residuo</strong> para convencerlos de que 
                la conservación es más valiosa que la caza.
                <br><br>
                <strong>Progreso:</strong><br>
                🧴 Plástico: ${counts.plastic}/30<br>
                🍾 Vidrio: ${counts.glass}/30<br>
                📰 Papel: ${counts.paper}/30<br>
                🍎 Orgánicos: ${counts.organic}/30
            </div>
            <div class="npc-dialog-buttons">
                ${
                  hasAll
                    ? '<button class="npc-dialog-btn accept" onclick="game.completeQuest2()">Entregar residuos</button>'
                    : '<button class="npc-dialog-btn decline" onclick="game.closeRangerDialog()">Volver luego</button>'
                }
                <button class="npc-dialog-btn decline" onclick="game.closeRangerDialog()">Cerrar</button>
            </div>
        `;
  }

  showQuestCompleteDialog(dialog) {
    dialog.innerHTML = `
            <div class="npc-dialog-title">🧑‍🌾 Guardabosques</div>
            <div class="npc-dialog-text">
                ¡Gracias a ti, guardián! Los cazadores han entendido el mensaje y 
                nuestra fauna está a salvo. Has demostrado ser un verdadero 
                <strong>Protector de la Pampa</strong>. 🌾💧
            </div>
            <div class="npc-dialog-buttons">
                <button class="npc-dialog-btn accept" onclick="game.closeRangerDialog()">Continuar</button>
            </div>
        `;
  }

  completeQuest1() {
    // Remover 13 botellas del inventario
    let removed = 0;
    for (
      let i = this.player.inventory.length - 1;
      i >= 0 && removed < 13;
      i--
    ) {
      if (this.player.inventory[i].type === "plastic") {
        this.player.inventory.splice(i, 1);
        removed++;
      }
    }

    this.player.updateInventoryUI();
    gameState.rangerQuest1Complete = true;
    gameState.hasWaterPurifier = true;
    gameState.checkLevelCompletion();

    this.closeRangerDialog();
    this.notifications.show(
      "¡Misión Completada! 🎉",
      "Has obtenido el Purificador de Agua Avanzado 🌊 (Presiona P para usar)",
      "success",
      5000
    );
  }

  completeQuest2() {
    // Remover 30 de cada tipo
    const typesToRemove = ["plastic", "glass", "paper", "organic"];
    typesToRemove.forEach((type) => {
      let removed = 0;
      for (
        let i = this.player.inventory.length - 1;
        i >= 0 && removed < 13;
        i--
      ) {
        if (this.player.inventory[i].type === type) {
          this.player.inventory.splice(i, 1);
          removed++;
        }
      }
    });

    this.player.updateInventoryUI();
    gameState.rangerQuest2Complete = true;
    gameState.checkLevelCompletion();

    this.closeRangerDialog();
    this.notifications.show(
      "¡Misión Completada! 🎉",
      "Has salvado la fauna de la pampa. ¡Eres un héroe!",
      "success",
      5000
    );
  }

  closeRangerDialog() {
    document.getElementById("npcDialog").style.display = "none";
    this.paused = false;
  }

  showVictoryScreen() {
    this.paused = true;

    const level = GAME_CONFIG.LEVELS[gameState.currentLevel - 1];

    document.getElementById(
      "victoryLevel"
    ).textContent = `Nivel ${gameState.currentLevel}`;
    document.getElementById("victoryPoints").textContent = gameState.points;
    document.getElementById("victoryWater").textContent =
      Math.round(gameState.waterQuality) + "%";
    document.getElementById("victoryWastes").textContent = gameState.collected;
    document.getElementById(
      "victoryUpgrades"
    ).textContent = `${gameState.upgrades.size}/${GAME_CONFIG.UPGRADES.length}`;

    const buttonsDiv = document.getElementById("victoryButtons");

    if (gameState.currentLevel === 3) {
      // Última nivel - mostrar pantalla final
      this.showFinalVictoryScreen();
      return;
    }

    // Niveles 1 y 2
    buttonsDiv.innerHTML = `
            <button class="btn btn-primary" onclick="game.quitGame()">Dejar de Jugar</button>
            <button class="btn btn-secondary" onclick="game.restartGame()">Empezar Desde Cero</button>
            <button class="btn btn-info" onclick="game.nextLevel()">Continuar al Nivel ${
              gameState.currentLevel + 1
            } 🎯</button>
        `;

    showScreen("victoryScreen");
  }

  showFinalVictoryScreen() {
    document.getElementById("finalTotalPoints").textContent =
      gameState.totalPointsAllLevels;
    document.getElementById("finalTotalWastes").textContent =
      gameState.totalCollectedAllLevels;

    showScreen("finalVictoryScreen");
  }

  nextLevel() {
    const nextLevelNum = gameState.currentLevel + 1;
    this.changeLevel(nextLevelNum);
    showScreen("gameScreen");
    this.paused = false;
  }

  restartGame() {
    gameState.reset();
    this.changeLevel(1);
    showScreen("gameScreen");
    this.paused = false;
  }

  quitGame() {
    this.running = false;
    this.paused = false;
    showScreen("startScreen");
  }

  // ============================================
  // SISTEMA DEL VILLANO CAZADOR
  // ============================================

  updateHunterSystem(timestamp) {
    // Spawn periódico del cazador
    if (
      !this.hunter.active &&
      timestamp - this.lastHunterSpawn > GAME_CONFIG.HUNTER.SPAWN_INTERVAL
    ) {
      this.spawnHunter();
      this.lastHunterSpawn = timestamp;
    }

    // Actualizar cazador si está activo
    if (this.hunter.active) {
      const escaped = this.hunter.update(timestamp);

      if (escaped) {
        this.hunterEscaped();
      }

      // Actualizar temporizador en pantalla
      this.updateHunterTimer();
      this.updateHunterArrow();
    }
  }

  spawnHunter() {
    this.hunter.spawn();

    // Mostrar alerta
    this.showHunterAlert();

    // Crear elemento de temporizador
    this.createHunterTimer();

    this.notifications.show(
      "⚠️ ¡Cazador Detectado!",
      "Atrápalo presionando E cerca de él. ¡Tienes 15 segundos!",
      "warning",
      4000
    );
  }

  showHunterAlert() {
    const alert = document.createElement("div");
    alert.className = "hunter-alert";
    alert.textContent = "⚠️ ¡CAZADOR FURTIVO DETECTADO! ⚠️";
    document.body.appendChild(alert);

    setTimeout(() => {
      if (document.body.contains(alert)) {
        document.body.removeChild(alert);
      }
    }, 3000);
  }

  createHunterTimer() {
    if (this.hunterTimerElement) {
      document.body.removeChild(this.hunterTimerElement);
    }

    this.hunterTimerElement = document.createElement("div");
    this.hunterTimerElement.className = "hunter-timer";
    document.body.appendChild(this.hunterTimerElement);
  }

  updateHunterTimer() {
    if (!this.hunterTimerElement || !this.hunter.active) return;

    const remaining = Math.ceil(this.hunter.getRemainingTime() / 1000);
    this.hunterTimerElement.textContent = `⏱️ Cazador escapa en: ${remaining}s`;

    if (remaining <= 0) {
      this.removeHunterTimer();
    }
  }

  removeHunterTimer() {
    if (
      this.hunterTimerElement &&
      document.body.contains(this.hunterTimerElement)
    ) {
      document.body.removeChild(this.hunterTimerElement);
      this.hunterTimerElement = null;
    }
  }

  updateHunterArrow() {
    const arrow = document.getElementById("hunterArrow");

    if (!this.hunter.active || !arrow) {
      if (arrow) arrow.style.display = "none";
      return;
    }

    // Mostrar flecha
    arrow.style.display = "block";

    // Calcular la posición del jugador en la pantalla (centro)
    const playerScreenX = this.canvas.width / 2;
    const playerScreenY = this.canvas.height / 2;

    // Posición del cazador en pantalla relativa a la cámara
    const hunterScreenX = this.hunter.x - this.camera.x;
    const hunterScreenY = this.hunter.y - this.camera.y;

    // Calcular vector dirección
    const dx = hunterScreenX - playerScreenX;
    const dy = hunterScreenY - playerScreenY;
    const distance = Math.sqrt(dx * dx + dy * dy);

    // Si el cazador está muy cerca o en pantalla, no mostrar flecha
    if (distance < 100) {
      arrow.style.display = "none";
      return;
    }

    // Calcular ángulo
    const angle = Math.atan2(dy, dx) * (180 / Math.PI);

    // Posicionar la flecha en el borde de la pantalla apuntando al cazador
    const arrowDistance = 100; // Distancia desde el centro de la pantalla
    const arrowX =
      playerScreenX + Math.cos((angle * Math.PI) / 180) * arrowDistance;
    const arrowY =
      playerScreenY + Math.sin((angle * Math.PI) / 180) * arrowDistance;

    // Aplicar posición y rotación
    arrow.style.left = arrowX + "px";
    arrow.style.top = arrowY + "px";
    arrow.style.transform = `translate(-50%, -50%) rotate(${angle}deg)`;
  }

  captureHunter() {
    this.hunter.capture();
    const arrow = document.getElementById("hunterArrow");
    if (arrow) arrow.style.display = "none";
    this.removeHunterTimer();

    // Dar recompensa
    const reward = GAME_CONFIG.HUNTER.REWARD_POINTS;
    gameState.addPoints(reward);

    this.notifications.show(
      "✅ ¡Cazador Capturado!",
      `Has ganado ${reward} puntos. ¡La fauna está a salvo!`,
      "success",
      5000
    );

    // Resetear tecla E
    keys["e"] = false;
  }

  hunterEscaped() {
    this.hunter.escape();
    const arrow = document.getElementById("hunterArrow");
    if (arrow) arrow.style.display = "none";
    this.removeHunterTimer();

    // Aplicar penalización
    const pointsPenalty = Math.floor(
      gameState.points * (GAME_CONFIG.HUNTER.PENALTY_POINTS_PERCENT / 100)
    );
    const waterPenalty = GAME_CONFIG.HUNTER.PENALTY_WATER;

    gameState.addPoints(-pointsPenalty);
    gameState.changeWaterQuality(-waterPenalty);

    this.notifications.show(
      "❌ El Cazador Escapó",
      `Perdiste ${pointsPenalty} puntos y ${waterPenalty}% de calidad del agua`,
      "error",
      5000
    );
  }

  update(timestamp) {
    if (this.paused) return;

    // Generar residuos
    if (timestamp - this.lastWasteSpawn > GAME_CONFIG.WASTE.SPAWN_INTERVAL) {
      this.spawnWaste();
      this.lastWasteSpawn = timestamp;
    }

    // Actualizar entidades
    this.wastes.forEach((waste) => waste.update(timestamp));
    this.containers.forEach((container) => container.update(timestamp));
    this.animals.forEach((animal) => animal.update());
    this.ranger.update(timestamp);

    // Movimiento del jugador
    let dx = 0,
      dy = 0;
    if (keys["w"] || keys["ArrowUp"]) dy -= 1;
    if (keys["s"] || keys["ArrowDown"]) dy += 1;
    if (keys["a"] || keys["ArrowLeft"]) dx -= 1;
    if (keys["d"] || keys["ArrowRight"]) dx += 1;

    if (dx !== 0 || dy !== 0) {
      // Normalizar movimiento diagonal
      const magnitude = Math.sqrt(dx * dx + dy * dy);
      dx /= magnitude;
      dy /= magnitude;
      this.player.move(dx, dy, this.world);
    }

    // Sistema de villano cazador
    this.updateHunterSystem(timestamp);

    // Recolección (solo si no estamos sobre un contenedor o si autoCollect está activo)
    if (keys["e"] && !this.nearContainer) {
      this.collectWaste();
    } else if (gameState.hasAutoCollect) {
      this.collectWaste();
    }

    // Intentar capturar al cazador
    if (
      keys["e"] &&
      this.hunter.active &&
      this.hunter.checkCapture(this.player)
    ) {
      this.captureHunter();
    }

    // Interacción con guardabosques (solo si no estamos cerca de un contenedor)
    if (!this.nearContainer) {
      this.checkRangerInteraction();
    }

    // Uso del purificador de agua (tecla P)
    if (keys["p"] && gameState.hasWaterPurifier) {
      gameState.useWaterPurifier();
      keys["p"] = false; // Evitar spam
    }

    // Verificar colisiones con contenedores
    this.checkContainerCollisions();

    // Intentar abrir depósito si estamos cerca y presionamos E
    this.tryOpenDeposit();

    // Actualizar cámara
    this.camera.follow(this.player);

    // Limpiar residuos recolectados antiguos
    if (this.wastes.length > 100) {
      this.wastes = this.wastes.filter(
        (w) => !w.collected || this.wastes.indexOf(w) > this.wastes.length - 50
      );
    }
  }

  draw() {
    // Limpiar canvas
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    // Dibujar mundo
    this.world.draw(this.ctx, this.camera);

    // Dibujar contenedores
    this.containers.forEach((container) =>
      container.draw(this.ctx, this.camera)
    );

    // Dibujar residuos
    this.wastes.forEach((waste) => waste.draw(this.ctx, this.camera));

    // Dibujar animales
    this.animals.forEach((animal) => animal.draw(this.ctx, this.camera));

    // Dibujar guardabosques
    this.ranger.draw(this.ctx, this.camera);

    // Dibujar cazador si está activo
    if (this.hunter.active) {
      this.hunter.draw(this.ctx, this.camera);
    }

    // Dibujar jugador
    this.player.draw(this.ctx, this.camera);

    // Indicador visual si estamos cerca de un contenedor
    if (this.nearContainer && this.player.inventory.length > 0) {
      const screenX = this.player.x - this.camera.x;
      const screenY = this.player.y - this.camera.y;
      this.ctx.fillStyle = "#F39C12";
      this.ctx.font = "bold 16px Arial";
      this.ctx.textAlign = "center";
      this.ctx.fillText(
        "Presiona E para depositar",
        screenX + this.player.size / 2,
        screenY - 30
      );
    }

    // Mini-mapa
    this.drawMinimap();
  }

  drawMinimap() {
    const minimapSize = 150;
    const minimapX = this.canvas.width - minimapSize - 20;
    const minimapY = 20;

    // Fondo del minimapa
    this.ctx.fillStyle = "rgba(0, 0, 0, 0.5)";
    this.ctx.fillRect(minimapX, minimapY, minimapSize, minimapSize);

    // Borde
    this.ctx.strokeStyle = "white";
    this.ctx.lineWidth = 2;
    this.ctx.strokeRect(minimapX, minimapY, minimapSize, minimapSize);

    // Escala
    const scaleX = minimapSize / GAME_CONFIG.WORLD_WIDTH;
    const scaleY = minimapSize / GAME_CONFIG.WORLD_HEIGHT;

    // Jugador
    this.ctx.fillStyle = "#FFD700";
    const playerMinimapX = minimapX + this.player.x * scaleX;
    const playerMinimapY = minimapY + this.player.y * scaleY;
    this.ctx.beginPath();
    this.ctx.arc(playerMinimapX, playerMinimapY, 4, 0, Math.PI * 2);
    this.ctx.fill();

    // Guardabosques
    this.ctx.fillStyle = "#00FF00";
    const rangerX = minimapX + this.ranger.x * scaleX;
    const rangerY = minimapY + this.ranger.y * scaleY;
    this.ctx.fillRect(rangerX - 3, rangerY - 3, 6, 6);

    // Contenedores
    this.ctx.fillStyle = "#27AE60";
    this.containers.forEach((container) => {
      const x = minimapX + container.x * scaleX;
      const y = minimapY + container.y * scaleY;
      this.ctx.fillRect(x - 2, y - 2, 4, 4);
    });

    // Residuos
    this.ctx.fillStyle = "#E74C3C";
    this.wastes
      .filter((w) => !w.collected)
      .forEach((waste) => {
        const x = minimapX + waste.x * scaleX;
        const y = minimapY + waste.y * scaleY;
        this.ctx.fillRect(x - 1, y - 1, 2, 2);
      });

    // Cazador si está activo
    if (this.hunter.active) {
      this.ctx.fillStyle = "#FF0000";
      const hunterX = minimapX + this.hunter.x * scaleX;
      const hunterY = minimapY + this.hunter.y * scaleY;
      this.ctx.beginPath();
      this.ctx.arc(hunterX, hunterY, 3, 0, Math.PI * 2);
      this.ctx.fill();
      // Borde pulsante
      this.ctx.strokeStyle = "white";
      this.ctx.lineWidth = 1;
      this.ctx.stroke();
    }
  }

  gameLoop(timestamp = 0) {
    if (!this.running) return;

    this.update(timestamp);
    this.draw();

    requestAnimationFrame((ts) => this.gameLoop(ts));
  }
}

// ============================================
// CONTROL DE TECLADO
// ============================================

const keys = {};

window.addEventListener("keydown", (e) => {
  keys[e.key.toLowerCase()] = true;
  keys[e.key] = true;

  if (
    e.key === "Escape" &&
    currentScreen === "gameScreen" &&
    game &&
    !game.paused
  ) {
    game.pause();
  }

  if (e.key === "i" || e.key === "I") {
    if (currentScreen === "gameScreen" && game && !game.paused) {
      openFullInventory();
    } else if (currentScreen === "fullInventoryScreen") {
      closeFullInventory();
    }
  }
});

window.addEventListener("keyup", (e) => {
  keys[e.key.toLowerCase()] = false;
  keys[e.key] = false;
});

// ============================================
// GESTIÓN DE PANTALLAS
// ============================================

let currentScreen = "startScreen";

function showScreen(screenId) {
  document.querySelectorAll(".screen").forEach((screen) => {
    screen.classList.remove("active");
  });
  document.getElementById(screenId).classList.add("active");
  currentScreen = screenId;
}

// ============================================
// GESTIÓN DE LA TIENDA
// ============================================

function updateShop() {
  document.getElementById("shopPoints").textContent = gameState.points;

  const shopItems = document.getElementById("shopItems");
  shopItems.innerHTML = GAME_CONFIG.UPGRADES.map((upgrade) => {
    const owned = gameState.upgrades.has(upgrade.id);
    const canAfford = gameState.points >= upgrade.cost;
    const requirementsMet =
      !upgrade.requires || gameState.upgrades.has(upgrade.requires);
    const canBuy = !owned && canAfford && requirementsMet;

    let statusText = "";
    if (owned) {
      statusText = "";
    } else if (!requirementsMet) {
      const reqUpgrade = GAME_CONFIG.UPGRADES.find(
        (u) => u.id === upgrade.requires
      );
      statusText = `<small style="color: #E74C3C;">Requiere: ${reqUpgrade.name}</small>`;
    } else if (!canAfford) {
      statusText = `<small style="color: #F39C12;">Puntos insuficientes</small>`;
    }

    return `
            <div class="shop-item ${owned ? "owned" : ""}">
                <div class="shop-item-icon">${upgrade.icon}</div>
                <div class="shop-item-name">${upgrade.name}</div>
                <div class="shop-item-description">${upgrade.description}</div>
                <div class="shop-item-price">${upgrade.cost} puntos</div>
                ${statusText}
                <button class="shop-item-btn" 
                        ${owned || !canBuy ? "disabled" : ""}
                        onclick="buyUpgrade('${upgrade.id}')">
                    ${owned ? "✓ Adquirido" : "Comprar"}
                </button>
            </div>
        `;
  }).join("");
}

function buyUpgrade(upgradeId) {
  if (gameState.buyUpgrade(upgradeId)) {
    const upgrade = GAME_CONFIG.UPGRADES.find((u) => u.id === upgradeId);
    game.notifications.show(
      "¡Mejora Adquirida!",
      upgrade.name + " - " + upgrade.description,
      "success",
      4000
    );
    updateShop();
  } else {
    game.notifications.show(
      "No se puede comprar",
      "Verifica los requisitos y puntos disponibles",
      "error",
      3000
    );
  }
}

// ============================================
// GESTIÓN DEL CONOCIMIENTO
// ============================================

function initKnowledgeTabs() {
  const tabButtons = document.querySelectorAll(".tab-btn");
  tabButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      // Remover active de todos
      tabButtons.forEach((b) => b.classList.remove("active"));
      document
        .querySelectorAll(".tab-content")
        .forEach((c) => c.classList.remove("active"));

      // Activar el seleccionado
      btn.classList.add("active");
      const tabId = btn.getAttribute("data-tab") + "Tab";
      document.getElementById(tabId).classList.add("active");
    });
  });
}

// ============================================
// EVENT LISTENERS E INICIALIZACIÓN
// ============================================

let game;

document.addEventListener("DOMContentLoaded", () => {
  // Verificar si hay guardado
  const hasSave = localStorage.getItem("guardianesDelaPampa_save");
  if (hasSave) {
    document.getElementById("continueBtn").style.display = "block";
  }

  // Inicializar tabs de conocimiento
  initKnowledgeTabs();

  // Botones de pantalla de inicio
  document.getElementById("newGameBtn").addEventListener("click", () => {
    gameState.reset();
    game = new Game();
    showScreen("gameScreen");
    game.start();
  });

  document.getElementById("continueBtn").addEventListener("click", () => {
    gameState.load();
    game = new Game();
    game.changeLevel(gameState.currentLevel);
    showScreen("gameScreen");
    game.start();
  });

  document.getElementById("tutorialBtn").addEventListener("click", () => {
    showScreen("tutorialScreen");
  });

  document.getElementById("aboutBtn").addEventListener("click", () => {
    showScreen("aboutScreen");
  });

  document.getElementById("closeTutorialBtn").addEventListener("click", () => {
    showScreen("startScreen");
  });

  document.getElementById("closeAboutBtn").addEventListener("click", () => {
    showScreen("startScreen");
  });

  // Botones de pausa
  document.getElementById("pauseBtn").addEventListener("click", () => {
    if (game) game.pause();
  });

  document.getElementById("resumeBtn").addEventListener("click", () => {
    if (game) game.resume();
  });

  document.getElementById("saveGameBtn").addEventListener("click", () => {
    if (gameState.save()) {
      game.notifications.show(
        "Partida Guardada",
        "Tu progreso ha sido guardado correctamente",
        "success"
      );
      document.getElementById("continueBtn").style.display = "block";
    }
  });

  document.getElementById("mainMenuBtn").addEventListener("click", () => {
    if (game) {
      game.running = false;
      game = null;
    }
    showScreen("startScreen");
  });

  // Botones de tienda
  document.getElementById("shopBtn").addEventListener("click", () => {
    updateShop();
    showScreen("shopScreen");
    if (game) game.paused = true;
  });

  // NUEVO: Botón de entregar al guardabosques
  document.getElementById("deliverBtn").addEventListener("click", () => {
    if (game && !game.paused) {
      game.deliverToRanger();
    }
  });

  document.getElementById("closeShopBtn").addEventListener("click", () => {
    showScreen("gameScreen");
    if (game) game.paused = false;
  });

  // Botones de conocimiento
  document.getElementById("knowledgeBtn").addEventListener("click", () => {
    showScreen("knowledgeScreen");
    if (game) game.paused = true;
  });

  document.getElementById("closeKnowledgeBtn").addEventListener("click", () => {
    showScreen("gameScreen");
    if (game) game.paused = false;
  });

  // Inventario completo
  document.getElementById("inventoryBtn").addEventListener("click", () => {
    openFullInventory();
  });

  document
    .getElementById("closeFullInventoryBtn")
    .addEventListener("click", () => {
      closeFullInventory();
    });

  // Botón de cerrar depósito (con cooldown)
  document.getElementById("closeDepositBtn").addEventListener("click", () => {
    if (game) game.closeDepositModal();
  });

  // Botones de victoria final
  document
    .getElementById("restartFullGameBtn")
    .addEventListener("click", () => {
      if (game) game.restartGame();
    });

  document.getElementById("backToMenuBtn").addEventListener("click", () => {
    if (game) game.quitGame();
  });
});

function openFullInventory() {
  if (!game || !game.player) return;

  const inv = game.player.inventory;
  document.getElementById(
    "fullInventoryDisplay"
  ).textContent = `${inv.length}/${game.player.maxInventory}`;

  const list = document.getElementById("fullInventoryList");
  if (inv.length === 0) {
    list.innerHTML =
      '<p style="color: #7F8C8D; text-align: center; padding: 40px;">Inventario vacío</p>';
  } else {
    // Agrupar por tipo
    const grouped = {};
    inv.forEach((waste) => {
      if (!grouped[waste.type]) {
        grouped[waste.type] = 0;
      }
      grouped[waste.type]++;
    });

    list.innerHTML = Object.entries(grouped)
      .map(([type, count]) => {
        const config = GAME_CONFIG.WASTE.TYPES[type];
        return `
                <div class="inventory-item ${type}">
                    <span class="inventory-item-icon">${config.icon}</span>
                    <div class="inventory-item-info">
                        <div class="inventory-item-name">${config.name} x${count}</div>
                        <div class="inventory-item-type">${config.info}</div>
                    </div>
                </div>
            `;
      })
      .join("");
  }

  showScreen("fullInventoryScreen");
  if (game) game.paused = true;
}

function closeFullInventory() {
  showScreen("gameScreen");
  if (game) game.paused = false;
}

console.log("🌾 Guardianes de la Pampa - Versión Mejorada Cargada ✅");
